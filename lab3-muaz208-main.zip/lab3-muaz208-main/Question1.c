#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Questions.h"



char *my_strcat(const char * const str1, const char * const str2){

	/* this is the pointer holding the string to return */
	char *z = NULL;
	

	/*write your implementation here*/

	int length1=0; //length of first string
	int length2=0; // length of second string
	int i=0;
	int m=0; // index variable

	length1=strlen(str1); //length of string1 (not including null character '\0')
	length2=strlen(str2); //length of string2 (not including null character '\0')



	z=calloc((length1+length2+1),sizeof(char)); // since we are concatinating the two strings essentially, we need length1 + length2 spaces in the array and +1 because we need the null character. Each space in the array will be of size 1 byte (this is the size of a char)
									// NOTE we don't need to manually go add the null character at the end of our character array bc calloc initizalizes each element in the allocated array memory to 0, so it will already have it at the end


	for (i=0;i<(length1);i++){// for loop to iterate the length of string 1 times so that we can append each character one by one from string 1
		z[m]=str1[i];//append each character
		m++; //increase the index variable so that the next character can go in the NEXT position
	}


	for (i=0;i<(length2);i++){//Now for loop to iterate the length of string 2 times so that we can append each character one by one from string 2 (The index variable m still retains its value from the previous loop so it will continue to append chars from the next position in the z array)
		z[m]=str2[i]; //append each character
		m++; //increase the index variable so that the next character can go in the NEXT position
	}


	/* finally, return the string*/
	return z;
}
