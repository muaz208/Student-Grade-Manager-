typedef struct {
	//complete your student definition here

	int student_id;
	char first_name[15];
	char last_name[15];
	int project1_grade;
	int project2_grade;
	double final_grade;
} student;
